document.addEventListener("DOMContentLoaded", () => {
  const cover = document.getElementById("cover");
  const main = document.getElementById("main");
  const openBtn = document.getElementById("openBtn");

  openBtn.addEventListener("click", () => {
    cover.classList.add("hidden");
    main.classList.remove("hidden");
    window.scrollTo(0, 0);
  });

  // Countdown: 23 Agustus 2026, pukul 08.00 WIB (UTC+7)
  const target = new Date("2026-08-23T08:00:00+07:00").getTime();

  function updateCountdown() {
    const now = Date.now();
    const diff = target - now;
    const ids = ["days","hours","minutes","seconds"];

    if (diff <= 0) {
      ids.forEach(id => document.getElementById(id).textContent = "0");
      return;
    }

    const days = Math.floor(diff / 86400000);
    const hours = Math.floor((diff % 86400000) / 3600000);
    const minutes = Math.floor((diff % 3600000) / 60000);
    const seconds = Math.floor((diff % 60000) / 1000);

    document.getElementById("days").textContent = days;
    document.getElementById("hours").textContent = hours;
    document.getElementById("minutes").textContent = minutes;
    document.getElementById("seconds").textContent = seconds;
  }
  updateCountdown();
  setInterval(updateCountdown, 1000);

  // Gallery lightbox
  const lightbox = document.getElementById("lightbox");
  const lightboxImg = document.getElementById("lightboxImg");
  const close = document.getElementById("closeLightbox");

  document.querySelectorAll(".gallery-item").forEach(btn => {
    btn.addEventListener("click", () => {
      lightboxImg.src = btn.dataset.full;
      lightbox.classList.remove("hidden");
    });
  });

  function closeLightbox() {
    lightbox.classList.add("hidden");
    lightboxImg.src = "";
  }
  close.addEventListener("click", closeLightbox);
  lightbox.addEventListener("click", e => {
    if (e.target === lightbox) closeLightbox();
  });
});
